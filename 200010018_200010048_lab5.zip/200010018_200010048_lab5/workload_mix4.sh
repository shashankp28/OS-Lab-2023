#!/bin/sh
./syscall &
./arithoh.sh &
./arithoh.sh &
./loop.sh &
./fstime.sh &
wait